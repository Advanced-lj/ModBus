#ifndef __STDIO_H__
#define __STDIO_H__

#define BUFSIZ 128
#define EOF 	(-1)

#endif

